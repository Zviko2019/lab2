// -------------------------------------------
//					Paragraph
// -------------------------------------------

#include "Paragraph.h"

void Paragraph::addLine(const Line& line)
{
}

tuple<bool, vector<int>> Paragraph::contains(const Word& search_word) const
{
	return {false, vector<int>{}};
}